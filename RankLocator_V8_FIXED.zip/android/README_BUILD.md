# Rank Locator V8 Native Android

This is the real Android direction for V8 GPS.

## What changed
- No `content://` file viewer is used.
- V8 HTML is packaged inside the Android APK as an app asset.
- Android requests FINE/COARSE location permissions natively.
- Android LocationManager obtains a fresh GPS/network position.
- Coordinates are passed into V8 through a secure JavaScript bridge.
- V8 then searches live OpenStreetMap/Overpass data for the nearest taxi rank.

## Build
Open the `android` folder in Android Studio and let Gradle sync.
Build an APK from Android Studio.

## Test
1. Install the APK on the Huawei phone.
2. Open Rank Locator.
3. Allow precise location.
4. Turn on Location/GPS.
5. V8 should automatically request a location and search for the nearest mapped taxi rank.

Note: this environment does not include the Android SDK/Gradle toolchain, so an APK cannot be compiled here. This ZIP is the native Android source project, not an APK.

## Building from your phone (no PC needed)

This project now has a GitHub Actions workflow at `.github/workflows/build-apk.yml`
that builds the APK on GitHub's servers. Steps, all doable from the Claude/GitHub
mobile app or a phone browser:

1. Create a **free GitHub account** if you don't have one, and create a new
   **public or private repo** (e.g. `rank-locator`).
2. Upload this whole `RankLocatorV8Native` project folder to that repo
   (GitHub's web UI supports drag-and-drop file/zip upload, or use the
   GitHub mobile app, or `git push` from Termux if you have `git` installed).
3. Go to the repo's **Actions** tab. The "Build Rank Locator APK" workflow
   runs automatically on push (or tap **Run workflow** to trigger it
   manually).
4. Wait a few minutes for the green checkmark, then open the finished run
   and scroll to **Artifacts** → download `RankLocator-debug-apk`. That's a
   zip containing `app-debug.apk`.
5. On your phone, unzip it (any file manager/zip app), tap `app-debug.apk`,
   and allow "install unknown apps" for your browser/files app if prompted.

This produces a **debug** build, fine for testing on your own phone. Play
Store distribution needs a signed **release** build (a separate step —
ask if you want that set up later).

