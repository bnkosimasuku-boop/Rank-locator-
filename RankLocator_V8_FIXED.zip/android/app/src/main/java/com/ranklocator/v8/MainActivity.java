package com.ranklocator.v8;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int LOCATION_REQUEST = 1001;
    private WebView webView;
    private LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setGeolocationEnabled(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new LocationBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");

        locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
    }

    private boolean hasFineLocation() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasCoarseLocation() {
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void sendJs(final String js) {
        runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    private void sendError(String message) {
        String safe = message.replace("\\", "\\\\").replace("'", "\\'");
        sendJs("window.onNativeLocationError && window.onNativeLocationError('" + safe + "')");
    }

    @SuppressLint("MissingPermission")
    private void startLocation() {
        if (!hasFineLocation() && !hasCoarseLocation()) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, LOCATION_REQUEST);
            return;
        }

        if (locationManager == null) {
            sendError("Location service unavailable");
            return;
        }

        boolean gps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        boolean network = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        if (!gps && !network) {
            sendError("Turn on Location/GPS in Android Settings");
            return;
        }

        Location best = null;
        if (gps) {
            Location x = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (x != null) best = x;
        }
        if (network) {
            Location x = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (x != null && (best == null || x.getTime() > best.getTime())) best = x;
        }

        if (best != null) {
            deliver(best);
        }

        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_HIGH);

        LocationListener listener = new LocationListener() {
            private boolean delivered = false;
            @Override public void onLocationChanged(Location location) {
                if (!delivered) {
                    delivered = true;
                    deliver(location);
                    try { locationManager.removeUpdates(this); } catch(Exception ignored) {}
                }
            }
            @Override public void onProviderEnabled(String provider) {}
            @Override public void onProviderDisabled(String provider) {}
            @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
        };

        try {
            if (gps) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener);
            if (network) locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000L, 0f, listener);
        } catch (SecurityException e) {
            sendError("Location permission was not granted");
        }
    }

    private void deliver(Location location) {
        double lat = location.getLatitude();
        double lon = location.getLongitude();
        float acc = location.hasAccuracy() ? location.getAccuracy() : 0f;
        sendJs("window.onNativeLocation && window.onNativeLocation("
                + lat + "," + lon + "," + acc + ")");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == LOCATION_REQUEST) {
            if (hasFineLocation() || hasCoarseLocation()) startLocation();
            else sendError("Location permission was denied. Allow it in Android Settings.");
        }
    }

    public class LocationBridge {
        @JavascriptInterface
        public void requestLocation() {
            runOnUiThread(() -> startLocation());
        }
    }
}
